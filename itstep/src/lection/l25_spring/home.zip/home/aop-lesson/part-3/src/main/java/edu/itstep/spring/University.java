package edu.itstep.spring;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class University {
    private List<Student> students = new ArrayList<>();

    public void addStudents() {
        students.add(new Student("Ivan Ivanov", 1, 4.5));
        students.add(new Student("Stepan Stepanov", 2, 4.2));
        students.add(new Student("Petr Petrov", 3, 3.5));
    }

    public List<Student> getStudents() {
        System.out.println("Information from method getStudents:");

        //students.get(3);

        System.out.println(students);

        return students;
    }
}
