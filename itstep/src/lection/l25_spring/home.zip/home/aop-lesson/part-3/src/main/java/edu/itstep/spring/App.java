package edu.itstep.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.List;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ConfigApp.class);

//        University university = context.getBean("university", University.class);
//        university.addStudents();
//
//        List<Student> students = university.getStudents();
//        System.out.println(students);

        Library library = context.getBean("library", Library.class);
        String bookName = library.returnBook();
        System.out.println("В библиотеку вернули книгу " + bookName);

        context.close();
    }
}
