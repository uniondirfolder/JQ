package edu.itstep.spring;

import org.springframework.stereotype.Component;

@Component
public class Library {

    public String returnBook() {
        System.out.println("Мы возвращаем книгу в Library");

        //создали исключение
        System.out.println(3/0);


        return "Java";
    }
}
