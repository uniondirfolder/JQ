package edu.itstep.spring;

import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

import java.util.List;

@Aspect
@Component
public class UniversityLoggingAspect {

//    @Before("execution(* getStudents())")
//    public void beforeGetStudentsLoggingAdvice() {
//        System.out.println("beforeGetStudentsLoggingAdvice: логируем получение списка студентов ПЕРЕД МЕТОДОМ getStudents");
//    }
//
//    @AfterReturning(pointcut = "execution(* getStudents())", returning = "students")
//    public void afterReturningGetStudentsLoggingAdvice(List<Student> students) {
//        Student firstStudent = students.get(0);
//        String name = firstStudent.getName();
//        name = "Mr. " + name;
//        firstStudent.setName(name);
//        firstStudent.setAvgGrade(firstStudent.getAvgGrade() + 1);
//
//        System.out.println("afterReturningGetStudentsLoggingAdvice: логируем после работы метода getStudents");
//
//    }
//
//    @AfterThrowing(pointcut = "execution(* getStudents())", throwing = "ex")
//    public void afterThrowingGetStudentsLoggingAdvice(Throwable ex) {
//        //нельзя обработать исключение
//        System.out.println("afterThrowingGetStudentsLoggingAdvice: логируем выброс исключения " + ex);
//    }
//

    @After("execution(* getStudents())")
    public void afterGetStudentsLoggingAdvice() {
        //невозможно получить ошибку или результат метода
        System.out.println("afterGetStudentsLoggingAdvice: логируем ЛЮБОЕ оконачание метода(нормальное/ошибка)");
    }
}
