package edu.itstep.spring;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class BookLoggingAspect {

    @Around("execution(public String returnBook())")
    public Object aroundReturnBookLoggingAdvice(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        System.out.println("aroundReturnBookLoggingAdvice: в библиотеку возвращают книгу");

        long begin = System.currentTimeMillis();


        try {
            Object object = proceedingJoinPoint.proceed();//вызов returnBook();
        } catch (Throwable e) {
            //здесь обработать можно исключение - ПЛОХО
            System.out.println("aroundReturnBookLoggingAdvice: было создано исключение " + e);

            //логирование данного исключения
            throw e;
        }


        long end = System.currentTimeMillis();

        System.out.println("aroundReturnBookLoggingAdvice: в билиотеку успешно вернули книгу");

        System.out.println("aroundReturnBookLoggingAdvice: метода returnBook работает за " + (end - begin));
        return "Hello!!!!";
    }
}
