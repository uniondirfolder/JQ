package edu.itstep.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class Test1
{
    public static void main( String[] args )
    {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(ConfigApp.class);

        UniversityLibrary universityLibrary = context.getBean("universityLibrary", UniversityLibrary.class);
        universityLibrary.getBook();
        universityLibrary.getMagazine();
    }
}
//Проблемы:
//Code tangling - переплетение бизнес-логики со служебным функционалом
//Code scattering - разбросанность служебного функционала
//Aspect-классы(логирование, проверка прав, обработка транзакций, обработка исключений,кэширование...

//Advice Типы: Before, After returning, After throwing, After finally, Around
//Шаблон Pointcut:
//execution( modifiers-pattern? return-type-pattern declaring-type-pattern?
// method-name-pattern(parameters-pattern) throws-pattern?)

//Join Point