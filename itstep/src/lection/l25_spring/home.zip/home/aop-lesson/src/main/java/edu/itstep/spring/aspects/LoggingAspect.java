package edu.itstep.spring.aspects;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Aspect
@Order(2)

public class LoggingAspect {

    @Before("edu.itstep.spring.aspects.MyPointcuts.allGetMethods()")//Pointcut
    public void beforeGetBookAdvice() {
        System.out.println("beforeGetBookAdvice: попытка получить книгу/журнал");
    }

}
