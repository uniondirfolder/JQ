package edu.itstep.spring;

import org.springframework.stereotype.Component;

@Component
public class UniversityLibrary {
    public void getBook() {
        System.out.println("Мы берем книгу из UniversityLibrary");
    }


    public void getMagazine() {
        System.out.println("Мы берем журнал из UniversityLibrary");
    }

}
