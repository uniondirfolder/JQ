package edu.itstep.spring.aspects;

import edu.itstep.spring.Book;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Aspect
@Order(2)

public class LoggingAspect {

    @Before("edu.itstep.spring.aspects.MyPointcuts.allAddMethods()")//Pointcut
    public void beforeAddBookAdvice(JoinPoint joinPoint) {//вся инфо про сигнатуру и параметры метода
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
//        System.out.println("methodSignature: " + methodSignature);
//        System.out.println("methodSignature.getMethod(): " + methodSignature.getMethod());
//        System.out.println("methodSignature.getReturnType(): " + methodSignature.getReturnType());
//        System.out.println("methodSignature.getName(): " + methodSignature.getName());

        if (methodSignature.getName().equals("addBook")) {
            Object[] objects = joinPoint.getArgs();
            for (Object object : objects) {
                if (object instanceof Book) {
                    Book book = (Book) object;
                    System.out.println("Информация о книге: название - " + book.getName() +
                            ", автор - " + book.getAuthor() + ", год издание - " + book.getYearOfPublication());
                } else if (object instanceof String) {
                    System.out.println("Книгу в библиотеку добавляет " + object);
                }
            }
        }
        System.out.println("beforeAddBookAdvice: попытка получить книгу/журнал");
    }

}
