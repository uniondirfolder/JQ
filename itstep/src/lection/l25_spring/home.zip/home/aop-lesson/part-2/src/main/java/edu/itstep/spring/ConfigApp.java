package edu.itstep.spring;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@ComponentScan("edu.itstep.spring")
@EnableAspectJAutoProxy
public class ConfigApp {

}
