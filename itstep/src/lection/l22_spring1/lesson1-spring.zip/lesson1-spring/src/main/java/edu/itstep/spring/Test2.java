package edu.itstep.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test2 {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context =
                new ClassPathXmlApplicationContext("applicationContext2.xml");

        //Dog dog = context.getBean("dog", Dog.class);

        Person person = context.getBean("person", Person.class);
        System.out.println(person);
        System.out.println(person.info());
        System.out.println(person.getPet());
        context.close();
    }
}
