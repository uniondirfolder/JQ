package edu.itstep.spring;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan("edu.itstep.spring")
@PropertySource("classpath:myApp.properties")
public class MyConfig {

}
