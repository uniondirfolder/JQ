package edu.itstep.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test1 {
    public static void main(String[] args) {

        ClassPathXmlApplicationContext context =
                new ClassPathXmlApplicationContext("applicationContext.xml");

       // Dog dog1 = context.getBean("myPet", Dog.class);
        Dog dog1 = (Dog)context.getBean("myPet");
        System.out.println("START");
        Dog dog2 = (Dog)context.getBean("myPet");
        System.out.println(dog1);
        System.out.println(dog2);


//        Person person = context.getBean("myPerson", Person.class);
//        person.callPet();
//        System.out.println(person.getLastName());

        System.out.println("finish");
        context.close();
    }
}
//stateless объекты -
//stateful объекты -

//Жизненный цикл бина
//1 Запуск приложения
//2 Начало работы Spring Container
//3 Создание бина
//4 DI внедряются зависимости
//5 init-method
//6 Бин готов для использования
//7 Использование этого бина
//8 Конец работы Spring Container(close)
//9 destory-method
//10 Остановка приложения
