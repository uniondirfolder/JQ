package edu.itstep.spring;

public interface Pet {
    void say();
}
