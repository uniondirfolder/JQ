package edu.itstep.spring;

import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

@Component
public class Dog implements Pet {
    public Dog() {
        System.out.println("Created Dog");
    }

    @Override
    public void say() {
        System.out.println("Гав-гав");
    }

    @PostConstruct
    private void init() {
        System.out.println("init Dog");
    }

    @PreDestroy
    private void destroy() {
        System.out.println("destroy Dog");
    }
}

