package edu.itstep.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test4 {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(ConfigApp.class);

//        Person person2 = context.getBean("personBean", Person.class);
//        Person person = context.getBean("personBean", Person.class);
//        System.out.println(person);
//        System.out.println(person.getPet());
//        System.out.println(person.info());

        context.close();
    }
}
