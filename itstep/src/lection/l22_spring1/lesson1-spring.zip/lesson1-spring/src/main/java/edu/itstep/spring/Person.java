package edu.itstep.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//@Component
public class Person {
   // @Autowired
    private Pet pet;
    @Value("${person.lastName}")
    private String lastName;
    @Value("${person.age}")
    private int age;


//    public Person() {
//        System.out.println("Created Person");
//    }

    //@Autowired
//    public Person(@Qualifier("dog") Pet pet) {
//        this.pet = pet;
//    }

    public Person(Pet pet) {
        System.out.println("created Person");
        this.pet = pet;
    }



//    public Person(Pet pet, String lastName, int age) {
//        System.out.println("Created Person");
//        this.pet = pet;
//        this.lastName = lastName;
//        this.age = age;
//    }

    public void callPet() {
        System.out.println("Hello, Pet!");
        pet.say();
    }

    public Pet getPet() {
        return pet;
    }

    //@Autowired
    public void setPet(Pet pet) {
        this.pet = pet;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String info() {
        return "Person{" +
                "pet=" + pet +
                ", lastName='" + lastName + '\'' +
                ", age=" + age +
                '}';
    }
}
