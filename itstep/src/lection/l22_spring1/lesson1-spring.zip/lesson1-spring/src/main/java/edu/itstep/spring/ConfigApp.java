package edu.itstep.spring;

import org.springframework.context.annotation.*;

@Configuration
@PropertySource("classpath:myApp.properties")
public class ConfigApp {

    @Bean
    @Scope("singleton")
    public Pet catBean() {

        return new Cat();
    }

    @Bean
    @Scope("singleton")
    public Person personBean() {
        System.out.println("!!!");
        return new Person(catBean());
    }

}
