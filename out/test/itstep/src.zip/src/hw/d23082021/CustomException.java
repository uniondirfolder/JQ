package hw.d23082021;
@Developer
public class CustomException extends Exception{
    public CustomException(String message) {
        super(message);
    }
}
