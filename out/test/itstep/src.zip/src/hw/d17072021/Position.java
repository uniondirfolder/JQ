package hw.d17072021;

public enum Position {
    FIRST,
    LAST
}
