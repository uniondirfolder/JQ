package hw.d06092021_p1;

public class ConstructorException extends Exception {
    public ConstructorException(String message) {
        super(message);
    }
}
