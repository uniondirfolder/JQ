package hw.d20072021.arch.place;


import hw.d20072021.data.capsula.Developer;
import hw.d20072021.data.container.Container;

@Developer
public final class Catalog{
    public Container container = new Container();
}
