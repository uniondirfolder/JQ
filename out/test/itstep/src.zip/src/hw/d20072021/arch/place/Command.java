package hw.d20072021.arch.place;

public enum Command {
    TO_CATEGORY,
    TO_LIST_PRODUCT,
    TO_DESCRIPTION,
    AD_TO_BASKET,
    TO_BASKET,
    RETURN,
    DEFAULT
}
