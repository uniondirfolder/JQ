package hw.d20072021.data.table;

import hw.d20072021.data.capsula.Developer;

@Developer
public interface InterfaceExternalTables {
    public void tableRefSave(Object[] nameAndRef);
}
