package hw.d20072021.test;

public class WrapInt {
    public int valueInt;
}
