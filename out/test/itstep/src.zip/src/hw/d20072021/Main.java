package hw.d20072021;


import hw.d20072021.arch.place.Trade;

public class Main {



    public static void main(String[] args) {
        Trade t = new Trade();
        t.run(t);

    }
}
