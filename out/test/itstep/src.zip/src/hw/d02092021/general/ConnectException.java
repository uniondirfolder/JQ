package hw.d02092021.general;

public class ConnectException extends Exception{
    public ConnectException(String message) {
        super(message);
    }
}
