package hw.d22082021.enums;

import hw.d22082021.abstracts.Developer;

@Developer
public enum CasinoSaid {
    YES,
    NO
}
