package hw.d22082021.abstracts;
@Developer
public interface Universal {
    boolean add(Object obj);
    boolean remove(Object obj);
}
