package hw.d19072021;


import hw.d19072021.arch.place.Trade;

public class Main {

    public static void main(String[] args) {
        Trade t = new Trade();
        t.run(t);



    }
}
