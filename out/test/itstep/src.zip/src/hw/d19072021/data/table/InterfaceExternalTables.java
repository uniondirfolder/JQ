package hw.d19072021.data.table;

import hw.d19072021.data.capsula.Developer;

@Developer
public interface InterfaceExternalTables {
    void tableRefSave(Object[] nameAndRef);
}
