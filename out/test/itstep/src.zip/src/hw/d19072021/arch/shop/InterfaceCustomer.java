package hw.d19072021.arch.shop;


import hw.d19072021.data.capsula.Developer;
import hw.d19072021.data.capsula.User;

@Developer
public interface InterfaceCustomer {
    User getCustomer();
}
