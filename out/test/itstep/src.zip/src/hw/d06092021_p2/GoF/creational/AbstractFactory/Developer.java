package hw.d06092021_p2.GoF.creational.AbstractFactory;

public interface Developer {
    void writeCode();
}
