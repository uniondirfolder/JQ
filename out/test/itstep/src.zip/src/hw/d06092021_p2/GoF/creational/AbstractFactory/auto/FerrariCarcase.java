package hw.d06092021_p2.GoF.creational.AbstractFactory.auto;

public class FerrariCarcase implements Carcase{

    @Override
    public void createCarcase() {
        System.out.println("Create ferrari carcase");
    }
}
