package hw.d06092021_p2.GoF.behavioral.Interpreter;

public interface Expression {
    boolean interpret(String context);
}
