package hw.d06092021_p2.GoF.structural.Decorator.Starbuzz;

public enum Size {
    TALL, GRANDE, VENTS;
}
