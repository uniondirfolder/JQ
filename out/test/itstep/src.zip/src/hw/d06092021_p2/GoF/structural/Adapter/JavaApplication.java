package hw.d06092021_p2.GoF.structural.Adapter;

public class JavaApplication {
    public void saveObject() {
        System.out.println("Saving java object.");
    }

    public void readObject() {
        System.out.println("Reading java object.");
    }

    public void changeObject() {
        System.out.println("Changing java object.");
    }

    public void removeObject() {
        System.out.println("Removing java object.");
    }
}
