package hw.d06092021_p2.GoF.structural.Bridge.Car;

public class Sedan implements Model {

    @Override
    public void showModel() {
        System.out.println("Sedan");
    }
}
