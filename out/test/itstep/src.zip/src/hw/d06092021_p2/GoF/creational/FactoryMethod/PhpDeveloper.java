package hw.d06092021_p2.GoF.creational.FactoryMethod;

public class PhpDeveloper implements Developer {

    @Override
    public void writeCode() {
        System.out.println("Php developer write php code");
    }
}
