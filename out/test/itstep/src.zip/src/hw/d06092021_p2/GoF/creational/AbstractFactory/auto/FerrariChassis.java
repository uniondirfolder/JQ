package hw.d06092021_p2.GoF.creational.AbstractFactory.auto;

public class FerrariChassis implements Chassis{

    @Override
    public void createChassis() {
        System.out.println("Create ferrari chassis");
    }
}
