package hw.d06092021_p2.GoF.structural.Adapter;

public interface Database {
    void insert();
    void select();
    void update();
    void delete();
}
