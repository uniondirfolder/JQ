package hw.d06092021_p2.GoF.behavioral.Command;

public interface Command {
    void execute();
}
