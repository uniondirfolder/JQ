package hw.d06092021_p2.GoF.structural.Decorator.Starbuzz;

public interface Coffee {
    String getName();
    double cost();
    Size getSize();
}
