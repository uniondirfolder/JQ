package hw.d06092021_p2.GoF.structural.Facade;

public class Job {
    public void doJob() {
        System.out.println("Job in progress...");
    };
}
