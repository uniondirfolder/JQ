package hw.d06092021_p2.GoF.creational.AbstractFactory.pepsi;


import hw.d06092021_p2.GoF.creational.AbstractFactory.Tester;

public class PepsiLabel implements Tester {

    @Override
    public void testCode() {
        System.out.println("Create pepsi lable");
    }
}
