package hw.d06092021_p2.GoF.structural.Flyweight;

public class JavaDeveloper implements Developer {

    @Override
    public void writeCode() {
        System.out.println("Java Developer write java code.");
    }
}
