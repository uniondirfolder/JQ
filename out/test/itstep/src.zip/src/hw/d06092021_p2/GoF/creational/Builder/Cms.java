package hw.d06092021_p2.GoF.creational.Builder;

public enum Cms {
    WORDPRESS, DRUPAL;
}
