package hw.d06092021_p2.GoF.behavioral.State;

public class Training implements Activity {
    @Override
    public void justDoIt() {
        System.out.println("Training...");
    }
}
