package hw.d06092021_p2.GoF.behavioral.Strategy.Game;

public interface WeaponBehavior {
    void useWeapon();
}
