package hw.d06092021_p2.GoF.structural.Bridge.Car;

public interface Model {
    void showModel();
}
