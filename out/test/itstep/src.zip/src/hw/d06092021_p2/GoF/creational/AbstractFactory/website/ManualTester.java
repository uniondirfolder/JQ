package hw.d06092021_p2.GoF.creational.AbstractFactory.website;


import hw.d06092021_p2.GoF.creational.AbstractFactory.Tester;

public class ManualTester implements Tester {

    @Override
    public void testCode() {
        System.out.println("Manual tester test website code");
    }
}
