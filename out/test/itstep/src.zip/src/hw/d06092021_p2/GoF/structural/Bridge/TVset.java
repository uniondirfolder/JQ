package hw.d06092021_p2.GoF.structural.Bridge;

public interface TVset {
    String getName();
    void on();
    void off();
    void tuneChannel();
}
