package hw.d06092021_p2.GoF.creational.FactoryMethod.Pizza;

public interface Pizza {
    void createPizza();
}
