package hw.d06092021_p2.GoF.creational.Builder.Traveling;

public enum Type {
    REST, TRIP, EXCURSION;
}
