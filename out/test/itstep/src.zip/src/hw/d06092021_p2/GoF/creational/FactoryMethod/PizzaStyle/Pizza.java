package hw.d06092021_p2.GoF.creational.FactoryMethod.PizzaStyle;

public interface Pizza {
    void createPizza();
}
