package hw.d06092021_p2.GoF.structural.Facade;

public class Program {
    public static void main(String[] args) {
        Facade facade = new Facade();

        facade.solvingProblem();
        facade.relaxTime();
    }
}
