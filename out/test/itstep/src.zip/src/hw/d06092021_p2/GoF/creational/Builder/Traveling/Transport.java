package hw.d06092021_p2.GoF.creational.Builder.Traveling;

public enum Transport {
    TRAIN, BUS, SHIP;
}
