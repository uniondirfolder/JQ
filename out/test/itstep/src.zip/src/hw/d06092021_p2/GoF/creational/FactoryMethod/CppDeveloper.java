package hw.d06092021_p2.GoF.creational.FactoryMethod;

public class CppDeveloper implements Developer {

    @Override
    public void writeCode() {
        System.out.println("C++ developer write С++ code");
    }
}
