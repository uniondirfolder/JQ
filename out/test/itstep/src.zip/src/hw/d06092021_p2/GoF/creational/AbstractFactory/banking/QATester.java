package hw.d06092021_p2.GoF.creational.AbstractFactory.banking;


import hw.d06092021_p2.GoF.creational.AbstractFactory.Tester;

public class QATester implements Tester {

    @Override
    public void testCode() {
        System.out.println("QA tester test banking code");
    }
}
