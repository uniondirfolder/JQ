package hw.d06092021_p2.GoF.behavioral.State;

public interface Activity {
    public void justDoIt();
}
