package hw.d06092021_p2.GoF.structural.Proxy;

public class Program {

    public static void main(String[] args) {
        Project project = new ProxyProject("");
        project.run();
    }
}
