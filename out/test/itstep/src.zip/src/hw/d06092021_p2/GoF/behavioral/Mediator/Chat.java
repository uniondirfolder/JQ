package hw.d06092021_p2.GoF.behavioral.Mediator;

public interface Chat {
    void sendMessage(String message, User user);
}
