package hw.d06092021_p2.GoF.structural.Flyweight;

public interface Developer {
    void writeCode();
}
