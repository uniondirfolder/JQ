package hw.d06092021_p2.GoF.behavioral.Observer;

import java.util.List;

public interface Observer {
    void handleEvent(List<String> vacancies);
}
