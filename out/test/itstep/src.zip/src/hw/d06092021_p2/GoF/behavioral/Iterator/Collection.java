package hw.d06092021_p2.GoF.behavioral.Iterator;

public interface Collection {
    Iterator getIterator();
}
