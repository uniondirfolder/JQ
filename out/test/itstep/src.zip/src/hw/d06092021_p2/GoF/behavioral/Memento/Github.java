package hw.d06092021_p2.GoF.behavioral.Memento;

public class Github {
    private Save save;

    public Save getSave() {
        return save;
    }

    public void setSave(Save save) {
        this.save = save;
    }
}
