package hw.d06092021_p2.GoF.structural.Proxy;

public interface Project {
    void run();
}
