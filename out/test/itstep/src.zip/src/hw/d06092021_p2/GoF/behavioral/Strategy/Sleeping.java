package hw.d06092021_p2.GoF.behavioral.Strategy;

public class Sleeping implements Activity {

    @Override
    public void justDoIt() {
        System.out.println("Sleping...");
    }
}
