package hw.d06092021_p2.GoF.behavioral.State.Sentence;

public interface State {
    String getName();
    String next();
}
