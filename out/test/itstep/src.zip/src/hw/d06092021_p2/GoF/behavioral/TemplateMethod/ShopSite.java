package hw.d06092021_p2.GoF.behavioral.TemplateMethod;

public class ShopSite extends SiteTemplate {
    @Override
    public void getContent() {
        System.out.println("More goods represents...");
    }
}
