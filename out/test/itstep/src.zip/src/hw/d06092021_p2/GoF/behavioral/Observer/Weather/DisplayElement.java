package hw.d06092021_p2.GoF.behavioral.Observer.Weather;

public interface DisplayElement {
    void display();
}
