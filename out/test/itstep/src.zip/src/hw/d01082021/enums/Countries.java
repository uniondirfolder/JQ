package hw.d01082021.enums;

import hw.d01082021.Developer;

@Developer
public enum Countries {
    USA,
    ENGLAND,
    CANADA,
    UKRAINE
}
