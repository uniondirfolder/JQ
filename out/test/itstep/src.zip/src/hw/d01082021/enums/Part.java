package hw.d01082021.enums;

import hw.d01082021.Developer;

@Developer
public enum Part {
    A789,
    C234,
    G765
}
