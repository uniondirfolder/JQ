package hw.d04092021;

@Developer
public class FileManagerException extends Exception{
    public FileManagerException(String message) {
        super(message);
    }
}
