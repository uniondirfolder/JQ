package lection.l10_exc_enum;

//import com.sun.istack.internal.NotNull;
//import com.sun.istack.internal.Nullable;

public class Main3 {
    public static void main(String[] args) {
//        System.out.println("start");
//
//        String arr[] = {"one", "two", "three", ""};
//        int index = 3;
//        try {
//            System.out.println("try");
//            System.out.println(arr[3].toUpperCase());
//            String data = arr[index];
//            System.out.println("stop");
//            System.out.println(data.toUpperCase());
//            System.out.println("here");//ctrl + alt + T
//        } catch (NullPointerException e) {
//            //e.printStackTrace();
//            System.out.println("обратились к пустой строке");
//        } catch (ArrayIndexOutOfBoundsException e) {
//            System.out.println("выход за пределы массива");
//        }
//        System.out.println("finish");

//        ArrayList<User> users = new ArrayList<>();
//        users.add(new User());
//        users.add(null);
//        users.add(new User());
//        System.out.println(users.size());
//
//        System.out.println(users);
//
//        User user = UtilUser.getExcpenciveUser(3000);
//        System.out.println(user.getName());
    }



















}
