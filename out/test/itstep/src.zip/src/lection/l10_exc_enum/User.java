package lection.l10_exc_enum;

public class User {
    private String name;//null
    private int age;//0

    public User() {
//        name = null;
//        age = 0;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
