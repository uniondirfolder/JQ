package lection.l10_exc_enum;
//
//import com.sun.istack.internal.Nullable;

public class UtilUser {
//    @Nullable
//    public static User getExcpenciveUser( int price) {
//        if (price == 3000) {
//            new User();
//        }
//        return null;
//    }
}
