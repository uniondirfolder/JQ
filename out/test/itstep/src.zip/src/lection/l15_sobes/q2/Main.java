package lection.l15_sobes.q2;

public class Main {
    public static void main(String[] args) {
        Integer integer1 = null;
        Integer integer2 = 0;
        int i1 = integer1;
        int i2 = integer2;
        System.out.println(integer1 == integer2);
    }
}
