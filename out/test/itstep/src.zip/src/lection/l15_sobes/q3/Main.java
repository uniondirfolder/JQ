package lection.l15_sobes.q3;

public class Main {
    public static void main(String[] args) {
        boolean a = false;
        boolean b = true;
        if ((a = b)) {
            System.out.println(a);
        }
    }
}
