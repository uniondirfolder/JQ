package lection.l15_sobes.q4;

public class Main {
    public static void main(String[] args) {
//        String s = " true ";
//        boolean b = Boolean.parseBoolean(s);
//        System.out.println(b);
    }
}
