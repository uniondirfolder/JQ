package lection.l15_sobes.q1;

class First {
}

class Second {
    public static void main(String[] args) {
        First first = new First();
    }
}