package lection.l15_sobes.q13;

public class Main {
    public static void main(String[] args) {
        int a = 1;
        int b = 2;
//        int temp = a;
//        a = b;
//        b = temp;
//        System.out.println(a);
//        System.out.println(b);
        //местами

//        a = a + b;//3
//        b = a - b;//1
//        a = a - b;//2
//        System.out.println(a);
//        System.out.println(b);


    }
}
