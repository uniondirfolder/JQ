package lection.l15_sobes.q15;

public class Test {
    public void method( int a) {
        System.out.println("method");
        //final???
    }
}
