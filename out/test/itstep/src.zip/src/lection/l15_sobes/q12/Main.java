package lection.l15_sobes.q12;

public class Main {
    public static void main(String[] args) {
//        int i = 5;
//        i = i++;
//        System.out.println(i);

//        int i = 5;
//        i = ++i + ++i;
//        System.out.println(i);
//
//        int i = 5;
//        i = i++ + ++i;
//        System.out.println(i);
//
//
//        int i = 5;
//        i = i++ + i++;
//        System.out.println(i);




    }
}
