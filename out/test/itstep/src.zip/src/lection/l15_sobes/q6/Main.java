package lection.l15_sobes.q6;

public class Main {
    public static void main(String[] args) {
        test(5);
    }

    public static void test(byte v) {
        System.out.println("byte");
    }

    public static void test(long v) {
        System.out.println("long");
    }
}
