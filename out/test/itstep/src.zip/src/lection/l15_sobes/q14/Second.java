package lection.l15_sobes.q14;

public interface Second {
    default void method() {
        System.out.println("second");
    }
}
