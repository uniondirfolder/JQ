package lection.l15_sobes.q14;

public interface First {
    default void method() {
        System.out.println("first");
    }
}
