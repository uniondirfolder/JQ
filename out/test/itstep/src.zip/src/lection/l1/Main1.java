package lection.l1;

public class Main1 {
    public static void main(String[] args) {
        //Типы данных

        //byte short int long
        int userAge = 30;
        long l = 1_000_000_000_000L;
        System.out.println(7);

        //float double
        double a = 3.14, b = 3.16;//ctrl + alt + L
        float f = 3.15F;//ctrl + shift + enter

        //boolean
        boolean isFinished = true;

        //char
        char ch = '*';
        System.out.println(isFinished);




    }
}
