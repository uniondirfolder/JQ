package lection.l1;

public class Main11 {
    public static void main(String[] args) {
        //константы и var
        final int key = 1;
        //key = 4;
        //var a = 1;

    }
}
