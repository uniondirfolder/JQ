package lection.l11_enum;

public class MyNumberException extends Exception{
    public MyNumberException(String message) {
        super(message);
    }
}
